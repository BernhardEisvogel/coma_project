# -*- coding: utf-8 -*-
"""
Coma Blatt 6

@author: Louisa Weber (Louisa.Weber@uni-konstanz.de)
"""
#Aufgabe 1b

import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0,10**5, 10**5)
a1=3
n1=5
a2=10
n2=7
y1=a1*(x**n1)
y2=a2*(x**n2)
plt.plot(plt.loglog(x),plt.loglog(y1), ".")
plt.plot(plt.loglog(x), plt.loglog(y2), ":")
plt.xlabel("x")
plt.legend(["3x^5","10x^7"])
plt.show()