# -*- coding: utf-8 -*-
"""
Coma Blatt 6

@author: Louisa Weber(Louisa.Weber@uni-konstanz.de)
"""
#Aufgabe 3a) 
import Methoden as met
import numpy as np


unsort=np.loadtxt("Zahlen_unsortiert.txt",delimiter="\n")
sort=met.sortierverfahren(unsort)
np.savetxt("Zahlen_sortiert.txt",sort,fmt="%.1f")


