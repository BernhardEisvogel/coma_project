# -*- coding: utf-8 -*-
"""
Coma Blatt 6

@author: Louisa Weber (Louisa.Weber@uni-konstanz.de)
"""
#Aufgabe 3a) Algorithmus 1

def sortierverfahren(L):
    """
    Sortiert eine Liste L bestehend aus Zahlen nach ihrer Größe

    Parameters
    ----------
    L : list
        unsortierte Liste (Eingabe)

    Returns
    -------
    L : list
        sortierte Liste

    """
    for i in range(0,len(L),1):
        W=L[i]
        j=i
        while (j>0) and (L[j-1]>W):
            L[j]=L[j-1]
            j=j-1
        L[j]=W
    return L